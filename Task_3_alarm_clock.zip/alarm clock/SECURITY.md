# Security Policy

### Supported Versions

The latest release from the `master` branch (i.e. production release, not beta or alpha) is the currently supported release.
Only one release is supported at a moment; we don't have seperate edge/nightly builds.

### Reporting a Vulnerability

Please report all security vulnerabilities to basulabs.developer@gmail.com, and I will reply back to you as soon as possible, typically within 48 hours.
